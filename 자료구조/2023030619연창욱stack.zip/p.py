# Practice 4. Palindromes and Balance
import sys
from collections import deque
# Return True if string is a palindrome; False otherwise
def isPalindrome(string): #O(n)
  # TODO
  box = []                                    #declare stack
  for i in range(len(string)):                #from the head of string, get each alphabet into stack. O(n)
    box.append(string[i])
  for i in range(len(string)): 
    if box.pop() != string[i]: return False   #check if stack's ith member and string's ith member is different. O(n)
  return True
  


# Return True if brackets are balanced in string; False otherwise
def balance(string):  #O(n)
  # TODO
  s_deque = []                   #declare 3 queues for parenthesis, brace, and square bracket.
  m_deque = []
  b_deque = [] 
  for i in string :              #from the head of string, execute for each single string. O(n)
    if i == '(':                 #if opening brackets, append for each queues
      s_deque.append('1')
    elif i =='{':
      m_deque.append('2')
    elif i == '[':
      b_deque.append('3')
      
    elif i == ')':               #if closing brackets, 1) check if corresponding queue is empty. 2) if empty, return False. 3) if not empty, remove corresponding one for offset. 
      if len(s_deque)!=0:
        s_deque.pop(0)
      else: return False
    elif i == '}':
      if len(m_deque)!=0:
        m_deque.pop(0)
      else: return False
    elif i == ']':
      if len(b_deque)!=0:
        b_deque.pop(0)
      else: return False
    
    else: continue         # continue if not bracket.
    
     

  if len(s_deque)==0 and len(m_deque)==0 and len(b_deque)==0: #after executing for all string, check if offest all occured so that length of queues are 0.
     return True
  else: return False 

    

if __name__ == "__main__":
  if len(sys.argv) != 3:
    raise Exception("Correct usage: [program] [input] [output]")
  with open(sys.argv[1], 'r') as inFile:
    lines = inFile.readlines()
  with open(sys.argv[2], 'w') as outFile:
    for line in lines:
      words = line.split()
      op = words[0]
      if op == 'P':
        if len(words) != 2:
          raise Exception("PALINDROME: invalid input")
        ret = "T" if isPalindrome(words[1]) else "F"
        outFile.write(ret+"\n")
      elif op == 'B':
        if len(words) != 2:
          raise Exception("BALANCE: invalid input")
        ret = "T" if balance(words[1]) else "F"
        outFile.write(ret+"\n")
      else:
        raise Exception("Undefined operator")     

        
