# Practice 4. Palindromes and Balance
import sys
from collections import deque

# Return True if string is a palindrome; False otherwise
def isPalindrome(string):
  # TODO
  flag=0
  slist = deque(map(str, string.rstrip()))
  while len(slist)>1 :
    if slist.popleft()==slist.pop() : continue
    else :
      flag=1
      break
  return True if flag==0 else False

# Return True if brackets are balanced in string; False otherwise
def balance(string):
  # TODO
  flag=0
  slist = deque(map(str, string.rstrip()))
  stack = []
  while slist :
    bs = slist.popleft()
    if bs=="(" or bs=="{" or bs=="[" : stack.append(bs)
    elif bs==")" or bs=="}" or bs=="]" :
      if stack : check = stack.pop()
      else :
        flag=1
        break
      if (bs==")" and check!="(") or (bs=="}" and check!="{") or (bs=="]" and check!="[") :
        flag=1
        break
  return True if flag==0 and not stack else False
  

if __name__ == "__main__":
  if len(sys.argv) != 3:
    raise Exception("Correct usage: [program] [input] [output]")
  with open(sys.argv[1], 'r') as inFile:
    lines = inFile.readlines()
  with open(sys.argv[2], 'w') as outFile:
    for line in lines:
      words = line.split()
      op = words[0]
      if op == 'P':
        if len(words) != 2:
          raise Exception("PALINDROME: invalid input")
        ret = "T" if isPalindrome(words[1]) else "F"
        outFile.write(ret+"\n")
      elif op == 'B':
        if len(words) != 2:
          raise Exception("BALANCE: invalid input")
        ret = "T" if balance(words[1]) else "F"
        outFile.write(ret+"\n")
      else:
        raise Exception("Undefined operator")

        
