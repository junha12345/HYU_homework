﻿#include <iostream>
#include <string>
#include <stdio.h>
#include <sstream>
#include <vector>
using namespace std;

const int NUM_OF_CHAT = 200;

vector<string> split(string input, char sep)
{
    vector<string> result;
    stringstream ss;
    string buffer;
    ss.str(input);
    while (getline(ss, buffer, sep)){
        result.push_back(buffer);
    }
    return result;
}

int getChatCount(string* _chatList)
{
    int i;
    for (i = 0; i < NUM_OF_CHAT; ++i)
    {
        string s = _chatList[i];
        if (s.empty() == true) break;
    }
    return i;
}

void printChat(string* _chatList)
{
    int count = getChatCount(_chatList);
    for (int i = 0; i < count; ++i)
    {
        cout << i << " " << _chatList[i] << endl;
    }
}

// Implement these functions
bool addChat(string* _chatList, string _chat) // returns true when adding chat is succeeded
{
    for (int i = 0; i < NUM_OF_CHAT; ++i) {
        if (_chatList[i].empty()) {
            _chatList[i] = _chat;
            return true;
        }
    }
    return false;
}
bool removeChat(string* _chatList, int _index) // returns true when removing chat is succeeded
{
    if (_index >= 0 and _index < NUM_OF_CHAT and !_chatList[_index].empty()) {
        _chatList[_index] = "";
        int i = _index;
        while (!_chatList[i + 1].empty()) {
            _chatList[i] = _chatList[i + 1];
            _chatList[i+1] = "";
            i++ ;
        }
        return true;
    }
    return false;
}

// Implement commented (/* */) areas in main function
int main(void)
{
    string* chats = new string[NUM_OF_CHAT];

    addChat(chats, "Hello, Comment Administrator!");
    addChat(chats, "How have you been?");
    addChat(chats, "I am an undergraduate.");
    addChat(chats, "I am taking Creative Software Design.");
    addChat(chats, "This class is awesome.");

    while (true)
    {
        string command;
        getline(cin, command);
        vector<string> result = split(command, ' ');
        if (result[0] == "#quit") {
            break;
        }
        else if (result[0] == "#remove") {
            if (result[1].size() == 1) {
                if (removeChat(chats, result[1][0] - '0')) printChat(chats);
            }
            else {
                if (result[1][1] == '-') {
                    int x = result[1][0] - '0';
                    int y = result[1][2] - '0';
                    for (int i = x; i < y + 1; i++) {
                        removeChat(chats, x);
                    }
                    printChat(chats);
                }
                else {
                    vector<string> nums = split(result[1], ',');
                    for (int i = 0; i < nums.size(); i++) {
                        removeChat(chats, stoi(nums[i])-i);
                    }
                    printChat(chats);
                }
            }
        }
        else if (addChat(chats, command)) printChat(chats);
    }
    // delete chatting list
    delete[] chats;
    return 0;
}

