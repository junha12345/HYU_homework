package week4;

public class Hamburger {
    int breads;
    int cheeses;
    int patties;
    int vegetables;
    int totalcal;
    public Hamburger(int breads, int cheese, int patties, int vegetables) {
        this.breads = breads;
        this.cheeses = cheese;
        this.patties = patties;
        this.vegetables = vegetables;
        this.totalcal = breads*80+cheese*100+patties*250+vegetables*20;
    }
    public void makeHamburger() {
        System.out.println("The calories in the food you ordered are: ");
        System.out.println("Bread Calories: "+this.breads*80);
        System.out.println("Cheese Calories: "+this.cheeses*100);
        System.out.println("Patty Calories: "+ this.patties *250);
        System.out.println("Vegetables Calories: "+this.vegetables*20);
    }
    public void calculatePrintCalories() {
        System.out.println("Total calories of the hamburger: "+this.totalcal+"\n");
    }
}
