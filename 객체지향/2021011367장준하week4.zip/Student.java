package week4;

public class Student {
    String name;
    int age;
    int grade;
}