package week4;

public class Car {
    String brand;
    String model;
    int price;
    double mileage;
    String color;
    public Car(String brand, String model, int price, double mileage, String color) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.mileage = mileage;
        this.color = color;
    }
}
