package week4;

import java.util.Scanner;

public class LA4 {

    public static void createOrder() {
        Scanner input = new Scanner(System.in);
        int n;
        System.out.print("Enter the number of items: ");
        n = input.nextInt();
        input.nextLine();
        ShoppingList[] shop = new ShoppingList[n];
        for(int i=0;i<n;i++) {
            shop[i] = new ShoppingList();
            System.out.printf("Enter details for item %d:\n", i+1);
            System.out.print("Item Name: ");
            shop[i].name = input.nextLine();
            System.out.print("Item Price: ");
            shop[i].price = input.nextInt();
            System.out.print("Item Count: ");
            shop[i].count = input.nextInt();
            input.nextLine();
        }
        getTotalAmount(shop, n);
    }
    public static void getTotalAmount(ShoppingList[] shop, int n) {
        int total = 0;
        System.out.println("All items entered:");
        for(int i=0;i<n;i++) {
            System.out.printf("Item Name: %s, Price: %d Won, Count: %d\n", shop[i].name, shop[i].price, shop[i].count);
            total += shop[i].price*shop[i].count;
        }
        System.out.printf("\nMoney needed : %d", total);
    }
    public static void main(String[] args) {
        createOrder();
    }
}
