package week4;

public class LA1 {
    public static void main(String[] args) {
        Student[] students = new Student[5];
        students[0] = new Student();
        students[0].name = "Mike";
        students[0].age = 15;
        students[0].grade = 90;
        students[1] = new Student();
        students[1].name = "Tom";
        students[1].age = 16;
        students[1].grade = 80;
        students[2] = new Student();
        students[2].name = "Dwen";
        students[2].age = 17;
        students[2].grade = 100;
        students[3] = new Student();
        students[3].name = "Kate";
        students[3].age = 10;
        students[3].grade = 80;
        students[4] = new Student();
        students[4].name = "Jane";
        students[4].age = 16;
        students[4].grade = 50;
        for (int i=0;i<5;i++) {
            System.out.println(students[i].name+" "+students[i].age+" "+students[i].grade);
        }
    }
}
