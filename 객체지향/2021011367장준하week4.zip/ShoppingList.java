package week4;

public class ShoppingList {
    String name;
    int price;
    int count;
}
