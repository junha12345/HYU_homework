package week4;

import java.util.Scanner;

public class LA3 {

    public static void main(String[] args) {
        work();
    }
    public static void work() {
        Scanner input = new Scanner(System.in);
        int check=0;
        while (check==0) {
            int bread, cheese, pattie, vegetable;
            System.out.println("Welcome our hamburger store!\n");
            System.out.print("Enter the number of breads: ");
            bread = input.nextInt();
            System.out.print("Enter the number of cheeses: ");
            cheese = input.nextInt();
            System.out.print("Enter the number of patties: ");
            pattie = input.nextInt();
            System.out.print("Enter the number of vegetables: ");
            vegetable = input.nextInt();
            Hamburger hamburger = new Hamburger(bread, cheese, pattie, vegetable);
            hamburger.makeHamburger();
            hamburger.calculatePrintCalories();
            check = additionalOrder();
        }
    }
    public static int additionalOrder() {
        Scanner input = new Scanner(System.in);
        int flag;
        System.out.println("Do you have additional order?");
        System.out.println("Please input 1 if 'yes' and 2 if 'no'");
        System.out.print("input: ");
        flag = input.nextInt();
        while (flag!=1 && flag!=2) {
            System.out.println("Please input 1 or 2.");
            System.out.printf("input: ");
            flag=input.nextInt();
            if (flag==1) return 0;
            if (flag==2) {
                System.out.println("Please come again next time.");
                return 1;
            }
        }
        if (flag==1) return 0;
        else {
            System.out.println("Please come again next time.");
            return 1;
        }
    }
}
