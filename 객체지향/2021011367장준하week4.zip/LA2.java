package week4;

public class LA2 {
    public static void main(String[] args) {
        int n=2;
        Car[] cars = new Car[n];
        cars[0] = new Car("Benz", "C Class",55000000, 14.0, "Black");
        cars[1] = new Car("Hyundai", "Sonata",30000000, 12.0, "Blue");
        for (int i=0;i<n;i++) {
            System.out.println("Brand: "+cars[i].brand+"\nModel Name: "+cars[i].model+"\nPrice: "+cars[i].price+" KRW\nMileage: "+cars[i].mileage+" km/l\nColor: "+cars[i].color+"\n");
        }
    }
}
