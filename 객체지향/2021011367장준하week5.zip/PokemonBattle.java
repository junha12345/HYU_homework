package week5;

import java.util.Scanner;

public class PokemonBattle {
    Scanner input = new Scanner(System.in);
    WildPokemon wp;
    PlayerPokemon pp;
    GameMessage gm;
    PokemonBattle(WildPokemon wp, PlayerPokemon pp, GameMessage gm) {
        this.wp = wp;
        this.pp = pp;
        this.gm = gm;
    }
    void displayEncounter() {
        gm.encounter();
    }
    void battleStart() {
        gm.battleoption();
        int choice = input.nextInt();
        if (choice==1) {
            gm.attack();
            wp.hp -= pp.attackpower;
            pp.hp -= wp.attackpower;
        }
        else if (choice==2) {
            gm.runaway();
            wp.hp = wp.maxHP;
            gm.Scenario();
        }
        else if (choice==3) {
            if (20<=(wp.hp/wp.maxHP)*100) {
                gm.catchfail();
                pp.hp -= wp.attackpower;
            }
            else {
                gm.catchsuccess();
                wp.hp = -100;
            }
        }
    }
}
