package week5;

import java.util.Scanner;

public class Rating extends Movie {
    Scanner input = new Scanner(System.in);
    double rating;
    String reviewer;
    Rating(String mt, String di, int ry) {
        super(mt,di,ry);
    }
    void ratingPoint() {
        System.out.print("Rating: ");
        this.rating = input.nextDouble();
        input.nextLine();
    }
    void ratingName() {
        System.out.print("Reviewer: ");
        this.reviewer = input.nextLine();
    }
    void printMovieDetails() {
        System.out.println("\nMovie Details:");
        System.out.println("Title: " + movieTitle);
        System.out.println("Director: " + director);
        System.out.println("Year: " + releaseYear);
        System.out.println("Rating: " + rating);
        System.out.println("Reviewer: " + reviewer);
    }
}
