package week5;

public class GameMessage {
    PlayerPokemon pp;
    WildPokemon wp;
    public GameMessage(PlayerPokemon pp, WildPokemon wp) {
        this.pp = pp;
        this.wp = wp;
    }
    void battleoption() {
        System.out.println("Do you want to (1) attack, (2) run away, or (3) use a Poketball?");
    }
    void encounter() {
        System.out.printf("Your %s's HP: %d. Wild %s's HP: %d\n", pp.name, pp.hp, wp.name, wp.hp);
    }
    void Scenario() {
        System.out.printf("Your encounter a wild %s\n", wp.name);
        System.out.printf("You choose %s to battle!\n", pp.name);
    }
    void catchfail() {
        System.out.printf("%s is too strong. It escaped the Pokeball!\n", wp.name);
    }
    void catchsuccess() {
        System.out.printf("You have successfully caught %s\n", wp.name);
    }
    void runaway() {
        System.out.println("You run away\n");
    }
    void attack() {
        System.out.printf("%s attacks back!\n", wp.name);
    }
    void lose() {
        System.out.printf("Your %s was defeated...\n", pp.name);
    }
    void win() {
        System.out.printf("You defeated the wild %s\n", wp.name);
    }
}
