package week5;

public class BookManagementProceduralMain {
    public static void main(String[] args) {
        String title = "The Great Gatsby";
        String author = "F. Scott Fitzgerald";
        int yearPublished = 1925;

        printBookDetails(title, author, yearPublished);
    }

    static void printBookDetails(String title, String author, int yearPublished) {
        System.out.println("Book Details:");
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Year Published: " + yearPublished);
    }
}
