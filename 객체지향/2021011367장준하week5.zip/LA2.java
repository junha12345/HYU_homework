package week5;

public class LA2 {
    public static void main(String[] args) {
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        book1.printBookDetails();
    }
}
