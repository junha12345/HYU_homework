package week5;

public class PlayerPokemon
{
    public int maxHP;
    public int hp;
    public int attackpower;
    String name;
    PlayerPokemon(String name, int maxHP, int attackpower) {
        this.maxHP = maxHP;
        this.hp = maxHP;
        this.attackpower = attackpower;
        this.name = name;
    }
    public boolean isAlive() {
        if (hp <= 0) return false;
        else return true;
    }
}
