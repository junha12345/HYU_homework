package week5;

import java.util.Scanner;

public class LA3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Rating movie1 = new Rating("Inception", "Christopher Nolan", 2010);
        movie1.ratingPoint();
        movie1.ratingName();
        movie1.printMovieDetails();
    }
}
