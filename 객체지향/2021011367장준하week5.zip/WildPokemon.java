package week5;

public class WildPokemon {
    public int maxHP;
    public int hp;
    public int attackpower;
    String name;
    WildPokemon(String name, int maxHP, int attackpower) {
        this.maxHP = maxHP;
        this.hp = maxHP;
        this.attackpower = attackpower;
        this.name = name;
    }
}
