package week5;

public class PokemonGame {
    public static void main(String[] args) {
        int flag=0;
        PlayerPokemon playerPokemon = new PlayerPokemon("Pikachu", 100, 35);
        WildPokemon wildPokemon = new WildPokemon("Eevee", 80,  15);
        GameMessage gameMessage = new GameMessage(playerPokemon, wildPokemon);
        gameMessage.Scenario();
        while (playerPokemon.isAlive()) {
            PokemonBattle pokemonBattle = new PokemonBattle(wildPokemon, playerPokemon, gameMessage);
            pokemonBattle.displayEncounter();
            pokemonBattle.battleStart();
            System.out.println();
            if (wildPokemon.hp<-0) {
                if (wildPokemon.hp!=-100) gameMessage.win();
                flag=1;
                break;
            }
        }
        if (flag==0) {
            gameMessage.lose();
        }
    }

}
