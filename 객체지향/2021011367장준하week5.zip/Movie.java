package week5;

public class Movie {
    public String movieTitle;
    public String director;
    public int releaseYear;
    public Movie(String movieTitle, String director, int releaseYear) {
        this.movieTitle = movieTitle;
        this.director = director;
        this.releaseYear = releaseYear;
        System.out.printf("Please put your name and raing for movie %s\n", movieTitle);
        System.out.println("Rating Details: ");
    }
}
