package week5;
public class Car {
    String model; // Model
    String manufacturer; // Manufacturer
    int year; // Year of manufacture
    public Car(String model, String manufacturer, int year) {
        this.model = model;
        this.manufacturer = manufacturer;
        this.year = year;
    }
    public Car(String model, String manufacturer) {
        this(model, manufacturer, 0);
    }
    public Car() {
        this(" ", " ", 0);
    }
    void displayInfo() {
        System.out.printf("Model: %s, Manufacturer: %s, Year: %d\n", model, manufacturer, year);

    }
}