package week3time1;

import java.util.Scanner;

public class LA3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int balance = 0;
        while (true) {
            System.out.println("--------------------------------------------------");
            System.out.println("1.Deposit | 2.Withdraw | 3.Check Balance | 4. Exit");
            System.out.println("--------------------------------------------------");
            int n;
            System.out.print("Choice: ");
            n = input.nextInt();
            if (n==1) {
                int k=0;
                System.out.print("Enter Deposit amount: ");
                k = input.nextInt();
                balance += k;
                System.out.printf("Deposited %d WON. Current balance: %d Won\n", k, balance);
            } else if (n==2) {
                int k=0;
                System.out.print("Enter withdrawl: ");
                k = input.nextInt();
                if (k>balance) System.out.printf("Tried to withdraw %d WON. but the balance is insufficient.\n", k);
                else {
                    balance-=k;
                    System.out.printf("Withdrawn %d WON. Current balance: %d WON\n", k, balance);
                }
            } else if (n==3) {
                System.out.printf("Current balance: %d WON\n", balance);
            } else if (n==4) {
                break;
            } else {
                System.out.println("Invalid choice. Please select again.");
            }
        }
        System.out.println("Exit the system.");
    }
}
