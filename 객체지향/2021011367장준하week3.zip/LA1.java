package week3time1;

import java.util.Scanner;

public class LA1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            int n=1;
            System.out.print("Enter the number of integers to input: ");
            n = input.nextInt();
            if (n==0) break;
            if (n<0) {
                System.out.println("Please enter an inter greater than 0.");
                continue;
            }
            int[] arr = new int[n];
            System.out.printf("Enter %d integers: ", n);
            int num, maxn=0, minn=2147483647;
            for (int i=0;i<n;i++) {
                num = input.nextInt();
                if (num>maxn) maxn=num;
                if (num<minn) minn=num;
                arr[i] = num;
            }
            System.out.printf("Min integer: %d\n", minn);
            System.out.printf("Max integer: %d\n", maxn);
        }
        System.out.println("Program Exit");
    }
}
