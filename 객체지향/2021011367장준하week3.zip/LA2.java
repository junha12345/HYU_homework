package week3time1;

import java.util.Scanner;

public class LA2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            int n;
            System.out.print("Enter the number of scores: ");
            n = input.nextInt();

            if (n==0) break;
            if (n<0) {
                System.out.println("The number of scores should be more than one.");
                continue;
            }
            int flag=0, sum=0;
            int[] arr = new int[n];
            while (true) {
                if (flag==0) System.out.print("Enter the score: ");
                else System.out.printf("Please enter %d scores again: ", n);
                flag=0;
                for (int i=0;i<n;i++) {
                    arr[i] = input.nextInt();
                }
                for (int i=0;i<n;i++) {
                    if (arr[i]>100 || arr[i]<0) {
                        System.out.println("The score should be in the range of (0~100).");
                        flag=1;
                        break;
                    }
                }
                if (flag==0) break;
            }
            for (int i=0;i<n;i++) sum += arr[i];
            double result = (double) sum / n;
            if (result<60) System.out.println("The grade is F");
            else if (result<70) System.out.println("The grade is D");
            else if (result<80) System.out.println("The grade is C");
            else if (result<90) System.out.println("The grade is B");
            else System.out.println("The grade is A");
        }
        System.out.println("Exit the program");
    }
}
