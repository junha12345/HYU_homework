package week3time1;

import java.util.Scanner;

public class LA4 {
    public static void showboard(String[][] arr) {
        for (int i=0;i<3;i++) {
            for (int j=0;j<3;j++) {
                System.out.print(arr[i][j]);
            }
            System.out.print("\n");
        }
    }

    public static int checkboard(String[][] arr) {
        int flag=0;
        if (arr[0][0]=="O" && arr[1][1]=="O" && arr[2][2]=="O") flag=1;
        if (arr[0][2]=="O" && arr[1][1]=="O" && arr[2][0]=="O") flag=1;
        if (arr[0][0]=="O" && arr[0][1]=="O" && arr[0][2]=="O") flag=1;
        if (arr[1][0]=="O" && arr[1][1]=="O" && arr[1][2]=="O") flag=1;
        if (arr[2][0]=="O" && arr[2][1]=="O" && arr[2][2]=="O") flag=1;
        if (arr[0][0]=="O" && arr[1][0]=="O" && arr[2][0]=="O") flag=1;
        if (arr[0][1]=="O" && arr[1][1]=="O" && arr[2][1]=="O") flag=1;
        if (arr[0][2]=="O" && arr[1][2]=="O" && arr[2][2]=="O") flag=1;

        if (arr[0][0]=="X" && arr[1][1]=="X" && arr[2][2]=="X") flag=2;
        if (arr[0][2]=="X" && arr[1][1]=="X" && arr[2][0]=="X") flag=2;
        if (arr[0][0]=="X" && arr[0][1]=="X" && arr[0][2]=="X") flag=2;
        if (arr[1][0]=="X" && arr[1][1]=="X" && arr[1][2]=="X") flag=2;
        if (arr[2][0]=="X" && arr[2][1]=="X" && arr[2][2]=="X") flag=2;
        if (arr[0][0]=="X" && arr[1][0]=="X" && arr[2][0]=="X") flag=2;
        if (arr[0][1]=="X" && arr[1][1]=="X" && arr[2][1]=="X") flag=2;
        if (arr[0][2]=="X" && arr[1][2]=="X" && arr[2][2]=="X") flag=2;

        return flag;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            int t = 0;
            String[][] array = {{"-","-","-"},{"-","-","-"},{"-","-","-"}};
            while (t<9) {
                showboard(array);
                if (t % 2 == 0) {
                    System.out.print("It's X's turn. Enter coordinates (for example 1 1): ");
                    int[] p = new int[2];
                    for (int i = 0; i < 2; i++) {
                        p[i] = input.nextInt();
                    }
                    if (array[p[0]-1][p[1]-1] != "-") {
                        System.out.println("Wrong coordinates. Coordinates that have already been previously selected.");
                        continue;
                    }
                    array[p[0]-1][p[1]-1] = "X";
                } else {
                    System.out.print("It's O's turn. Enter coordinates (for example 1 1): ");
                    int[] p = new int[2];
                    for (int i = 0; i < 2; i++) {
                        p[i] = input.nextInt();
                    }
                    if (array[p[0]-1][p[1]-1] != "-") {
                        System.out.println("Wrong coordinates. Coordinates that have already been previously selected.");
                        continue;
                    }
                    array[p[0]-1][p[1]-1] = "O";
                }
                if (checkboard(array)==1) {
                    System.out.println("O wins!");
                    break;
                }
                else if (checkboard(array)==2) {
                    System.out.println("X wins!");
                    break;
                }
                t += 1;
            }
            if (checkboard(array)==0) System.out.println("Draw!");
            System.out.print("Do you want play more? (YES=1 / NO=2)\n");
            int flag = input.nextInt();
            if (flag == 1) continue;
            else break;
        }
        System.out.println("Thanks for playing");
    }
}
