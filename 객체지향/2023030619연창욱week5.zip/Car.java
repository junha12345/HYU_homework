package week5;

public class Car {
    String model;
    String manufacturer;
    int year;
    //Todo
    Car(){
        this("","",0);
    }

    Car(String model, String manufacturer){
        this.model = model;
        this.manufacturer = manufacturer;
    }
    Car(String model, String manufacturer, int year){
        this.model = model;
        this. manufacturer = manufacturer;
        this.year = year;
    }
    void displayInfo(){
        System.out.println("Model: "+model+", Manufacturer: "+manufacturer+", Year: "+year);
    }
}
