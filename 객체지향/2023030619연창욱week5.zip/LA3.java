package week5;
import java.util.Scanner;
public class LA3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please put your name and rating for movie 'Inception'");
        System.out.println("Rating Details:");
        System.out.print("Rating: ");
        double rating = in.nextDouble();
        System.out.print("Reviewer: ");
        String reviewer = in.next();

        Movie mov = new Movie("Inception","Christopher Nolan",2010);
        System.out.println("Movie Details:");
        mov.printMovie();
        Rating rat = new Rating(rating,reviewer);
        rat.printRating();
    }
}
