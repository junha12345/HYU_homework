package week5;

public class Movie {
    String movieTitle;
    String director;
    int releaseYear;
    Movie(String movieTitle, String director, int releaseYear){
        this.movieTitle = movieTitle;
        this.director = director;
        this.releaseYear = releaseYear;
    }
    void printMovie(){

        System.out.println("Title: "+movieTitle);
        System.out.println("Director: "+director);
        System.out.println("Year: "+releaseYear);

    }
}
