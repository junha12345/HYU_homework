package week5;

public class Rating {
    double rating;
    String reviewer;
    Rating(double rating, String reviewer){
        this.rating = rating;
        this.reviewer = reviewer;
    }

    void printRating(){
        System.out.println("Rating: "+rating);
        System.out.println("Reviewer: "+reviewer);
    }

}
