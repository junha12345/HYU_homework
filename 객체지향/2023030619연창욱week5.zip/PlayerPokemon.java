package week5;

public class PlayerPokemon {
    String name;
    int maxHp;
    int hp;
    int attackPower;
    boolean isAlive(){
        if (hp>0) return true;
        else return false;
    }
    PlayerPokemon(String name, int maxHp, int attackPower){
        this.name = name;
        this.maxHp = maxHp;
        this.attackPower = attackPower;
        this.hp = maxHp;
    }
}
