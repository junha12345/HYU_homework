package week5;

import org.w3c.dom.ls.LSOutput;

public class GameMessage {

    public void stateChoice(){
        System.out.println("Your Pickachu's HP: "+PokemonBattle.Pickachu.hp+". Wild Eevee's HP: "+PokemonBattle.Eevee.hp);
        System.out.println("Do you want to (1) attack, (2) run away, or (3) use a Poketball?");

    }

}