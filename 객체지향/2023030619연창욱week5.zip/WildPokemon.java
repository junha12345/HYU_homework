package week5;

public class WildPokemon {
    String name;
    int maxHP;
    int attackPower;
    int hp;
    WildPokemon(String name, int maxHP, int attackPower){
        this.name = name;
        this.maxHP = maxHP;
        this.attackPower = attackPower;
        this.hp = maxHP;
    }
    boolean isAlive(){
        if (hp>0) return true;
        else return false;
    }
}
