package week5;
import java.util.Scanner;
public class PokemonBattle {
    Scanner in = new Scanner(System.in);

    GameMessage gameMessage = new GameMessage();
    public static WildPokemon Eevee = new WildPokemon("",2,2);
    public static PlayerPokemon Pickachu = new PlayerPokemon("",2,2);
    GameMessage gameM = new GameMessage();
    PokemonBattle(WildPokemon wildPokemon, PlayerPokemon playerPokemon, GameMessage gameMessage){
        Eevee = wildPokemon;
        Pickachu = playerPokemon;
    }
    void displayEncounter(){
        System.out.println(" ");
        System.out.println("You encountered a wild Eevee!");
        System.out.println("You choose Pickachu to battle!");
    }
    void battleStart(){

        gameMessage.stateChoice();
        int choice = 0;
        while(Eevee.isAlive()) {
            choice = in.nextInt();
            if (choice == 1) {
                Eevee.hp -= Pickachu.attackPower;

                Pickachu.hp -= Eevee.attackPower;
                if (!Pickachu.isAlive()){
                    System.out.println("Eevee attacks back!");
                    System.out.println("Your Pickachu was defeated...");
                    break;
                }
                else if (!Eevee.isAlive()){
                    System.out.println("You defeated the wild Eevee!");
                    Pickachu.hp+=Eevee.attackPower;
                    break;
                }
                System.out.println("Eevee attacks back!");

            } else if (choice == 2) {
                System.out.println("You run away");
                break;
            } else if (choice == 3) {
                if (Eevee.hp < 16) {System.out.println("You have successfully caught Eevee!"); break;}

                else {
                    System.out.println("Eevee is too strong. It escaped the Poketball!");
                    Pickachu.hp -= Eevee.attackPower;
                }
            }
            gameM.stateChoice();
        }
    }
}
